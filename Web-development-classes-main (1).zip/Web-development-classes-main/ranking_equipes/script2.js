document.querySelectorAll('#table th').forEach(header => {
    header.addEventListener('click', () => {
      const table = header.closest('table');
      const tbody = table.querySelector('tbody');
      const rows = Array.from(tbody.querySelectorAll('tr'));
      const index = Array.from(header.parentNode.children).indexOf(header);
      const isAscending = header.classList.contains('ascending');
       // Ordenar as linhas da tabela de acordo com o valor da coluna selecionada
      rows.sort((a, b) => {
        const aVal = a.children[index].textContent.trim();
        const bVal = b.children[index].textContent.trim();
        return aVal.localeCompare(bVal, undefined, { numeric: true });
      });
       // Alternar entre ordem crescente e decrescente a cada clique
      if (isAscending) {
        rows.reverse();
        header.classList.remove('ascending');
        header.classList.add('descending');
      } else {
        header.classList.remove('descending');
        header.classList.add('ascending');
      }
       // Recriar a tabela com as linhas ordenadas
      tbody.innerHTML = '';
      rows.forEach(row => tbody.appendChild(row));
    });
  });
   // Adicionar listener de entrada no campo de pesquisa
  document.querySelector('#search').addEventListener('input', () => {
    const table = document.querySelector('#table');
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const searchText = document.querySelector('#search').value.toLowerCase();
     // Filtrar as linhas da tabela para exibir apenas aquelas que correspondem ao texto inserido
    rows.forEach(row => {
      const rowText = Array.from(row.children).map(td => td.textContent.trim()).join('').toLowerCase();
      if (rowText.includes(searchText)) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });
  });
 
 
  document.getElementById("search-input").addEventListener("input", function() {
    // código para filtrar a tabela aqui
  });
 
 
  var searchText = document.getElementById("search-input").value;
 
 
  var rows = document.querySelectorAll("table tr");
 
 
 for (var i = 0; i < rows.length; i++) {
  var cells = rows[i].querySelectorAll("td");
  var match = false;
 
 
  for (var j = 0; j < cells.length; j++) {
    if (cells[j].textContent.toLowerCase().indexOf(searchText.toLowerCase()) !== -1) {
      match = true;
      break;
    }
  }
 
 
  rows[i].style.display = match ? "" : "none";
 }
 
 
 
 
 
 
 

 
 


 
 
 
 
 